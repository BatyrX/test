class ElementSelector {
  constructor() {
    this.selectedElement = null;
    this.enabled = false;
    this.isShiftPressed = false;
    this.isZPressed = false;
    this.isXPressed = false; // Добавили отслеживание X
    this.currentAnswer = null;
    this.questionsData = [];
    this.init();
    this.loadQuestionData();
  }

  async loadQuestionData() {
    this.questionsData = await this.getQuestionData();
  }

  init() {
    this.injectStyles();
    this.addEventListeners();
    this.createUI();
  }

  injectStyles() {
    const style = document.createElement("style");
    style.textContent = `
        .element-highlight {
          outline: 2px solid #3498db !important;
          cursor: crosshair !important;
        }
        .answer-overlay {
          position: fixed;
          bottom: 20px;
          right: 20px;
          padding: 15px;
          border-radius: 8px;
          z-index: 999999;
          max-width: 350px;
          background: white;
          box-shadow: 0 4px 15px rgba(0,0,0,0.2);
          border: 1px solid #ccc;
          font-family: sans-serif;
          transition: opacity 0.2s;
          pointer-events: none;
        }
        .math-item {
          margin-bottom: 8px;
          color: #2c3e50;
          font-size: 14px;
        }
      `;
    document.head.appendChild(style);
  }

  createUI() {
    this.overlay = document.createElement("div");
    this.overlay.className = "answer-overlay";
    this.overlay.style.opacity = "0";
    document.body.appendChild(this.overlay);
  }

  addEventListeners() {
    document.addEventListener("keydown", (e) => {
      if (e.key === "Shift") this.isShiftPressed = true;
      if (e.key.toLowerCase() === "z") this.isZPressed = true;
      if (e.key.toLowerCase() === "x") {
        this.isXPressed = true;
        this.checkShowStatus(); // Проверяем, нужно ли показать окно
      }
    });

    document.addEventListener("keyup", (e) => {
      if (e.key === "Shift") {
        this.isShiftPressed = false;
        this.hideAnswer();
      }
      if (e.key.toLowerCase() === "z") this.isZPressed = false;
      if (e.key.toLowerCase() === "x") {
        this.isXPressed = false;
        this.hideAnswer(); // Скрываем, когда отпустили X
      }
    });

    document.addEventListener("mousedown", (e) => {
      if (this.isShiftPressed && this.isZPressed && e.button === 0) {
        this.selectElement(e);
      }
    }, true);

    document.addEventListener("mouseover", (e) => {
        if (this.isShiftPressed && this.isZPressed) {
            this.enabled = true;
            this.highlightElement(e);
        }
    });
    
    document.addEventListener("mouseout", () => {
        this.removeHighlight();
        this.enabled = false;
    });
  }

  checkShowStatus() {
    // Показываем только если зажаты И Shift И X
    if (this.isShiftPressed && this.isXPressed) {
      this.showAnswer();
    }
  }

  normalizeText(text) {
    return text
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]/gu, " ") 
      .replace(/\s+/g, " ")
      .trim();
  }

  showAnswer() {
    if (this.selectedElement && this.currentAnswer) {
      this.overlay.style.opacity = "1";
    }
  }

  hideAnswer() {
    this.overlay.style.opacity = "0";
  }

  highlightElement(e) {
    if (!this.enabled) return;
    this.removeHighlight();
    this.hoveredElement = e.target;
    this.hoveredElement.classList.add("element-highlight");
  }

  removeHighlight() {
    if (this.hoveredElement) {
      this.hoveredElement.classList.remove("element-highlight");
    }
  }

  tokenSortRatio(a, b) {
    const tokenize = (str) => [...new Set(str.split(" ").sort())];
    const aTokens = tokenize(a);
    const bTokens = tokenize(b);
    const intersection = aTokens.filter((t) => bTokens.includes(t)).length;
    const union = new Set([...aTokens, ...bTokens]).size;
    return Math.round((intersection / union) * 100);
  }

  findAllMatches(inputText) {
    const cleanInput = this.normalizeText(inputText);
    const matches = [];

    for (const item of this.questionsData) {
      const cleanQuestion = this.normalizeText(item.question);
      const score = this.tokenSortRatio(cleanInput, cleanQuestion);

      if (score > 60) {
        matches.push({
          variant: item.variant,
          score: score,
        });
      }
    }
    return this.processMatches(matches);
  }

  processMatches(matches) {
    return matches.sort((a, b) => b.score - a.score);
  }

  async getAnswer(text) {
    const matches = this.findAllMatches(text);
    return {
      answer: matches.map((m) => m.variant),
    };
  }

  async selectElement(e) {
    e.preventDefault();
    this.selectedElement = e.target;
    this.removeHighlight();
    
    const text = this.getCleanText(this.selectedElement);
    const response = await this.getAnswer(text);
    this.currentAnswer = response.answer;

    if (this.currentAnswer && this.currentAnswer.length > 0) {
      this.overlay.innerHTML = this.currentAnswer
        .map((ans, i) => `<div class="math-item">${i + 1}. ${ans}</div>`)
        .join("");

      if (window.renderMathInElement) {
        renderMathInElement(this.overlay, {
          delimiters: [
            { left: "$$", right: "$$", display: true },
            { left: "$", right: "$", display: false },
            { left: "\\(", right: "\\)", display: false },
            { left: "\\[", right: "\\]", display: true }
          ],
          throwOnError: false
        });
      }
    } else {
      this.overlay.innerHTML = `<div style="color: #ff4757;">Ответ не найден</div>`;
    }
  }

  getCleanText(element) {
    return element.textContent
      .replace(/[\n\t]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  async getQuestionData() {
    try {
      const response = await fetch(chrome.runtime.getURL('osnovy_nir.json'));
      return await response.json();
    } catch (error) {
      console.error('Error loading JSON:', error);
      return [];
    }
  }
}

new ElementSelector();